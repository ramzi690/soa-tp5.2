@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://service/")
package proxy;
